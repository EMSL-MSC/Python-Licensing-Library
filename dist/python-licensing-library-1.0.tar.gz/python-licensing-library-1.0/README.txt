This code is written and tested with Python 3.6


Before installing the Python-Licensing-Library package, please make sure that you have already installed Python and have an application to unpack a '*.tar.gz' file

Installation Instructions:

1. Extract the package
2. Under the directory containing 'setup.py', execute command 'python setup.py install'
3. Install glob2. Under the directory containing 'requirements.txt', execute command 'pip install -r requirements.txt'
To verify installation of dependency use 'pip list'
4. The package is ready to be used. For assistance on how to use the tool, execute 'python prepend_header.py --help'