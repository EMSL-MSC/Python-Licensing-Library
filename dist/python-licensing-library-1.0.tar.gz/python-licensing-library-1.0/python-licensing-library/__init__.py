# Python-Licensing-Library: python-licensing-library/__init__.py
#
# Copyright (c) 2017 Pacific Northwest National Laboratory (see the file NOTICE).
#
# This material is released under the ECL-2.0 license (see the file LICENSE).
#
# This material is released under warranty (see the file WARRANTY).

__author__ = 'Van A. Nguyen'
__version__ = (1,0)
