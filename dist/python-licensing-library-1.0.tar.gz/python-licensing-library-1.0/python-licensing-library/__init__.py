# Python-Licensing-Library: __init__.py
# Copyright (c) 2017 Pacific Northwest National Laboratory.
# See LICENSE for details.

__author__ = 'Van Nguyen'
__version__ = (1,0)